import bpy
from .render_variables import replaceVariables

class RENDERKIT_OT_render_node(bpy.types.Operator):
	bl_idname = "node.render_node"
	bl_label = "Render Active Node to Texture"
	bl_options = {'REGISTER', 'UNDO'}
	
	resolution_x: bpy.props.IntProperty(name="Resolution X", default=4096)
	resolution_y: bpy.props.IntProperty(name="Resolution Y", default=4096)
	samples: bpy.props.IntProperty(name="Samples", default=16)
	color_space: bpy.props.EnumProperty(
		name="Color Space",
		items=[
			('sRGB', "sRGB", ""),
			('Linear', "Linear", ""),
		],
		default='Linear'
	)
	render_device: bpy.props.EnumProperty(
		name="Render Device",
		items=[
			('CPU', "CPU", ""),
			('GPU', "GPU", ""),
		],
		default='GPU'
	)
	filepath: bpy.props.StringProperty(name="File Path", default="//{project}/{item}-{material}-{node}.png")
	uv_map: bpy.props.StringProperty(name="UV Map", default="")
	node_output: bpy.props.StringProperty(name="Node Output", default="")
	
	def execute(self, context):
		prefs = bpy.context.preferences.addons[__package__].preferences
		settings = bpy.context.scene.render_kit_settings
		
		# Check for active mesh object
		obj = context.active_object
		if not obj or obj.type != 'MESH':
			self.report({'ERROR'}, "No active mesh object selected")
			return {'CANCELLED'}
		
		# Check for active node
		node = context.active_node
		if not node:
			self.report({'ERROR'}, "No active node selected")
			return {'CANCELLED'}
		
		# Get active scene
		scene = context.scene
		
		# Store original settings
		original_device = scene.cycles.device
		original_samples = scene.cycles.samples
		original_bake = scene.cycles.bake_type
		
		# Set the render device
		if self.render_device == 'GPU':
			scene.cycles.device = 'GPU'
		else:
			scene.cycles.device = 'CPU'
		
		# Ensure the selected UV map exists
		uv_map = obj.data.uv_layers.get(self.uv_map)
		if not uv_map:
			self.report({'ERROR'}, f"UV map '{self.uv_map}' not found")
			return {'CANCELLED'}
		obj.data.uv_layers.active = uv_map
		
		# Create a new image to bake to
		image = bpy.data.images.new("BakedTexture", width=self.resolution_x, height=self.resolution_y)
		
		# Add an image texture node to the material for baking
		material = obj.active_material
		node_tree = material.node_tree
		image_node = node_tree.nodes.new(type='ShaderNodeTexImage')
		image_node.image = image
		image_node.select = True
		node_tree.nodes.active = image_node
		
		# Connect the selected node output to the image texture node
		links = node_tree.links
		links.new(node.outputs[self.node_output], image_node.inputs['Color'])
		
		# Set bake settings
		scene.cycles.samples = self.samples
		scene.cycles.bake_type = 'EMIT'
		scene.render.bake.use_clear = True
		scene.render.bake.use_selected_to_active = False
		scene.render.bake.use_split_materials = False
		
		# Bake the procedural texture to the image
		bpy.ops.object.bake(type='EMIT')
		
		# Save the baked image
		if not os.path.exists(self.filepath):
			os.makedirs(self.filepath)
		image.filepath_raw = bpy.path.abspath(self.filepath)
		image.file_format = 'PNG'
		image.save()
		
		# Remove the temporary image texture node
		node_tree.nodes.remove(image_node)
		
		self.report({'INFO'}, f"Baked texture saved to {self.filepath}")
		return {'FINISHED'}
	
	def draw(self, context):
		layout = self.layout
		obj = context.active_object
		
		if obj and obj.type == 'MESH':
			layout.prop_search(self, "uv_map", obj.data, "uv_layers")
			
		node = context.active_node
		if node:
			layout.prop(self, "node_output", text="Node Output")
			
		layout.prop(self, "resolution_x")
		layout.prop(self, "resolution_y")
		layout.prop(self, "samples")
		layout.prop(self, "color_space")
		layout.prop(self, "render_device")
		layout.prop(self, "filepath")
		
class BakeNodeOutputPanel(bpy.types.Panel):
	bl_label = "Bake Node Output to Image"
	bl_idname = "NODE_PT_bake_node_output"
	bl_space_type = 'NODE_EDITOR'
	bl_region_type = 'UI'
	bl_category = 'Bake Node'
	
	@classmethod
	def poll(cls, context):
		return context.active_node
	
	def draw(self, context):
		layout = self.layout
		layout.operator(RENDERKIT_OT_render_node.bl_idname)
		
def menu_func(self, context):
	self.layout.operator(RENDERKIT_OT_render_node.bl_idname)
	
def register():
	bpy.utils.register_class(RENDERKIT_OT_render_node)
	bpy.utils.register_class(BakeNodeOutputPanel)
	bpy.types.NODE_MT_context_menu.append(menu_func)
	
def unregister():
	bpy.utils.unregister_class(RENDERKIT_OT_render_node)
	bpy.utils.unregister_class(BakeNodeOutputPanel)
	bpy.types.NODE_MT_context_menu.remove(menu_func)
	
if __name__ == "__main__":
	register()
	